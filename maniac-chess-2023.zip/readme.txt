Thank you for downloading this Chess program. This readme file has been updated as of September, 2023.

Background: Created in 2001 for a college project and initially shared online. This is a re-release with an updated readme file.

Changes: Made minor adjustments to some configuration files.

Source Code: I don't have access to the original code, so major modifications aren't possible.

Compatibility: Designed for Windows. I've not been successful running it with Wine on Mac.

Images: Some copyrighted images were used in the original development. The software is and will remain free.

Engine Strength: Suitable for casual play and exploring different chess variants. If you're looking for more advanced engines, there are stronger options available. Check the links on the hosting website.

Please read the disclaimer before use.

DISCLAIMER AND TERMS OF USE

By accessing, downloading, or using this Maniac Chess software program (hereinafter referred to as "the 
Software"), you 
hereby acknowledge and agree to the following terms:

No Warranty or Liability: The author and distributor of the Software explicitly disclaims any and all 
warranties, whether expressed or implied, related to the Software. You understand that the Software is 
provided "as is" without any guarantee of functionality, safety, or appropriateness for a particular 
purpose. In no event shall the author, contributors, or anyone associated with the Software be held liable 
for any damages, losses, or any negative consequences that may result from using the Software.

Your Responsibility: By choosing to use the Software, you accept full responsibility for any and all 
results, outcomes, or effects, both intended and unintended, that may arise from its use. You are advised 
to exercise due diligence and caution while using the Software.

Distribution Rights: You are granted the right to freely distribute the Software, provided that all 
accompanying files, documentation, and original materials are included without alteration. The Software 
must be distributed without charge, and no monetary gains should be derived directly from its distribution 
without explicit written permission from the author.

Use at Your Own Risk: All users are explicitly informed that they are using the Software entirely at their 
own risk. It is the user's responsibility to assess the Software's suitability for their specific needs, 
to ensure proper installation, and to maintain appropriate safeguards like backups.

By proceeding with the installation or use of the Software, you indicate your understanding of and 
agreement with the above terms. Should you not agree with these terms, you are advised not to access, 
install, or use the Software.

Please send comments/suggestions to: lovingsubra@gmail.com

Website: https://maniac10001.tripod.com/main.html

My email: LovingSubra@gmail.com (do not use the email listed in the program)
